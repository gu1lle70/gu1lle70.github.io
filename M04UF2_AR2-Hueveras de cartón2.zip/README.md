# gu1lle70.github.io

-¿Qué es HTML? ¿CSS? ¿Javascript?
Los tres son lenguajes que se utilizan en front end de paginas web
HTML: es el lenguaje que se utiliza para crear el esqueleto de la web
CSS: es el lenguaje para poder dar estilo/disenyo a la web
Javascript: es el lenguaje para dar funcionalidad a la web animaciones etc


-¿Qué es el formato Markdown?

Es para dar formato simple en un html por ejemplo cursiva , parrafos etc para dar esqueleto a la web

-¿Qué es el formato JSON? ¿Cómo se convierte un objeto a JSON? ¿Y JSON a un objeto?

Un JSON es un formato que es parecido al XML el cual utiliza objetos JSON

